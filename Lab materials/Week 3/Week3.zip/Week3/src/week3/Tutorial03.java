/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week3;
import java.util.Scanner;
/**
 *
 * @author Fadzli Sham Hussin
 */
public class Tutorial03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Q1
        //a
        System.out.println(3*8 ==27);
        //b
        Scanner input = new Scanner(System.in);
        int N = input.nextInt();
        if(N % 2 == 0){
            System.out.println("This number is even");
        }
        else{
            System.out.println("This number is odd");
        }
        //C
        char C = input.next().charAt(0);
        if(C >= 'A'&& C <= 'Z'){
            System.out.println("This is capital letter");  
        }
        else{
            System.out.println("This is not capital letter");
        }
        //D
        String s1,s2;
        s1 = input.next();
        s2 = input.next();
        if(s1.compareToIgnoreCase(s2)<0){
            System.out.println(s1);
            System.out.println(s2);
        }
        else{
            System.out.println(s2);
            System.out.println(s1);
        }
        //E
        int day;
        day = input.nextInt();
        switch(day){
            case 0:
                System.out.println("Sunday");
                break;
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            default:
                System.out.println("Invalid input! Please enter a number between 0 and 6.");
        }
        //Q2
        /*
        if (num1 = num2){
            System.out.println("Number 1 is equal to number 2.");
        }
        */
        /*
          if (x > y && y > z)
               System.out.println("x is the largest number");
         */
        /*
        String s1, s2;
   
        if (s1.equals(s2))
             System.out.println("They are equal strings.");
        else
             System.out.println("They are not equal strings.");
        */
        /*
        if (x > 0 || y > 0)
            System.out.println("Either x or y is positive");
        */
        /*3a
        #####
        $$$$$
        */
        /*3b
        #####
        $$$$$
        */
        /* 3c
        #####
        */
        /*3d
        No output
        */
        //4
        int int1,int2,int3;
        int1 = input.nextInt();
        int2 = input.nextInt();
        int3 = input.nextInt();
        if (int1 >= int2 && int1 >= int3){
            System.out.println("Biggest number: " + int1);
        }
        else if(int2 >= int1 && int2 >= int3){
        System.out.println("Biggest number: " + int2);
        }
        else{
            System.out.println("Biggest number: " + int2);  
        }
        //5
        int year = input.nextInt();
        if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0){
            System.out.println("Leap year");
        }
        else{
            System.out.println("This is not a leap year");
        }
        
        
    }
    
}
