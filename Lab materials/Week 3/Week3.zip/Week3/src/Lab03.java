/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Fadzli Sham Hussin
 */
import java.util.Scanner;
import java.util.Random;
public class Lab03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //Q1
        System.out.println("Enter two integers and operation \"+,-,*,%,/\"");
        System.out.print("Enter first integer: ");
        int int1 = input.nextInt();
        System.out.print("Enter second integer: ");
        int int2 = input.nextInt();
         System.out.print("Enter operand: ");
        char operator = input.next().charAt(0);
        switch(operator){
            case '+':
                System.out.println(int1+int2);
                break;
            case '-':
                System.out.println(int1-int2);
                break;
            case '*':
                System.out.println(int1*int2);
                break;
            case '/':
                if(int2==0){
                    System.out.println("Error:");
                }
                else{
                    System.out.println(int1/int2);
                }
                break;
            case '%':
                if(int2 ==0){
                    System.out.println("Error");
                }
                else{
                    System.out.println(int1%int2);
                }
                break;
            default:
                System.out.println("Wrong operand");
                break;
                
        }
        //Q2
        Random random = new Random();
        int number = random.nextInt(6);
        String[] array = {"zero", "one", "two", "three", "four", "five"};
        System.out.println(number + " is "+ array[number]);
        
        //Q3
        System.out.print("Enter sales volume: ");
        int sales = input.nextInt();
        double commission,rate;
        if(sales <= 100){
            rate = 0.05;            
        }
        else if(sales > 100 && sales <= 500){
            rate = 0.075;
        }
        else if(sales > 500 && sales <= 1000){
            rate = 0.1;
        }
        else{
            rate = 0.125;
        }
        commission = sales*rate;
        System.out.printf("Your commision is: %.2f\n",commission);
        input.nextLine();
        
        //Q4
        Random rand = new Random();
        System.out.println("Player1: Press ENTER to roll dice");
        input.nextLine();
        int p11 = rand.nextInt(6)+1;
        System.out.println("Player2: Press ENTER to roll dice");
        input.nextLine();
        int p21 = rand.nextInt(6)+1;
        System.out.println("Player1: Press ENTER to roll dice");
        input.nextLine();
        int p12 = rand.nextInt(6)+1;
        System.out.println("Player2: Press ENTER to roll dice");
        input.nextLine();
        int p22 = rand.nextInt(6)+1;
        int sum1 = p11 + p12;
        int sum2 = p21 + p22;
        if(sum1 > sum2){
            System.out.println("Player 1 wins with a score of " + sum1 + " compared to Player 2 with a score of " + sum2);
        }
        else if(sum2 > sum1){
            System.out.println("Player 2 wins with a score of " + sum2 + " compared to Player 1 with a score of " + sum1);
        }
        else{
            System.out.println("It is a tie");
        }
        //Q5
        double x =0;
        double y=0;
        System.out.print("Enter a: ");
        double a = input.nextDouble();
        
        System.out.print("Enter b: ");
        double b = input.nextDouble();
        
        System.out.print("Enter c: ");
        double c = input.nextDouble();
        
        System.out.print("Enter d: ");
        double d = input.nextDouble();
        
        System.out.print("Enter e: ");
        double e = input.nextDouble();
        
        System.out.print("Enter f: ");
        double f = input.nextDouble();
        double denominator = (a*d)-(b*c);
        if(denominator == 0){
            System.out.println("The equation has no solution");
        }
        else{
            x = (e * d - b * f) / (denominator);
            y = (a * f - e * c) / (denominator);
            
        }
        System.out.printf("X = %.2f\n", x);
        System.out.printf("Y = %.2f\n ", y);
        
        //  Q6
        System.out.print("Enter the radius of the circle: ");
        double radius = input.nextDouble();

        // Ask for the coordinate point (x, y)
        System.out.print("Enter the x-coordinate: ");
        double x1 = input.nextDouble();

        System.out.print("Enter the y-coordinate: ");
        double y1 = input.nextDouble();

        // Calculate the squared distance from the center (0, 0) to the point
        // Formula: distance squared = x^2 + y^2
        double distanceSquared = (x1 * x1) + (y1 * y1);
        double radiusSquared = radius * radius;
        if (distanceSquared <= radiusSquared) {
            System.out.println("The point is inside the circle.");
        } else {
            System.out.println("The point is outside the circle.");
        }
                
        
        
    }
    
}
