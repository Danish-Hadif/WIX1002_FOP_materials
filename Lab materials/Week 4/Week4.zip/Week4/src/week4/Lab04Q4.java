/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Scanner;

/**
 *
 * @author Fadzli Sham Hussin
 */
public class Lab04Q4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        // 1. Accept inputs from the user
        System.out.print("Enter the year: ");
        int year = input.nextInt();

        System.out.print("Enter the first day of the year (0 for Sunday, 1 for Monday, ..., 6 for Saturday): ");
        int firstDayOfYear = input.nextInt();

        // 2. Check if it's a leap year inline
        boolean isLeap = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
        int febDays = isLeap ? 29 : 28;

        // 3. Calculate starting days for May and August
        int daysBeforeMay = 31 + febDays + 31 + 30;
        int mayStartDay = (firstDayOfYear + daysBeforeMay) % 7;

        int daysBeforeAugust = daysBeforeMay + 31 + 30 + 31;
        int augustStartDay = (firstDayOfYear + daysBeforeAugust) % 7;
        System.out.println("\n------------------------------------");
        System.out.println("             May " + year);
        System.out.println("------------------------------------");
        System.out.println("Sun  Mon  Tue  Wed  Thu  Fri  Sat");
        // Loop to print leading spaces for the first week
        for (int i = 0; i < mayStartDay; i++) {
            System.out.print("     ");
        }
        // Loop to print the days of May (31 days)
        for (int day = 1; day <= 31; day++) {
            System.out.printf("%-5d", day);
            if ((day + mayStartDay) % 7 == 0) {
                System.out.println();
            }
        }
        System.out.println("\n------------------------------------");
        System.out.println("\n------------------------------------");
        System.out.println("           August " + year);
        System.out.println("------------------------------------");
        System.out.println("Sun  Mon  Tue  Wed  Thu  Fri  Sat");
        // Loop to print leading spaces for the first week
        for (int i = 0; i < augustStartDay; i++) {
            System.out.print("     ");
        }
        // Loop to print the days of August (31 days)
        for (int day = 1; day <= 31; day++) {
            System.out.printf("%-5d", day);
            if ((day + augustStartDay) % 7 == 0) {
                System.out.println();
            }
        }
        System.out.println("\n------------------------------------");
        
    }
}
