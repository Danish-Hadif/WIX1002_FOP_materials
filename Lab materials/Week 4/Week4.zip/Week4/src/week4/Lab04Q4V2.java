/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Scanner;
/**
 *
 */
public class Lab04Q4V2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
         // 1. Get input from user
     System.out.print("Enter the year: ");
     int year = sc.nextInt();

     System.out.print("Enter the first day of the year (0-6): ");
     int firstDayOfYear = sc.nextInt();

     // 2. Calculate the first day of November
     boolean isLeapYear = (year % 4 == 0 && year % 100 != 0)
             || (year % 400 == 0);

     int dayUntilNov = 31 + (isLeapYear ? 29 : 28)
             + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31;

     int firstDayOfNov = (firstDayOfYear + dayUntilNov) % 7;

     // Convert Sunday-based numbering to Monday-based numbering
     int firstDayMonday = (firstDayOfNov + 6) % 7;

     String columnFormat = "%4s";
     String format = "%4s%4s%4s%4s%4s%4s%4s%n";

     // 3. Print November calendar starting from Monday
     System.out.println("\nNovember " + year);
     System.out.printf(format, "Mon", "Tue", "Wed",
             "Thu", "Fri", "Sat", "Sun");

     for (int i = 0; i < firstDayMonday; i++) {
         System.out.printf(columnFormat, "");
     }

     for (int i = 1; i <= 30; i++) {
         System.out.printf(columnFormat, i);

         if ((i + firstDayMonday) % 7 == 0) {
             System.out.println();
         }
     }

     System.out.println();
     }
        
    }
    

