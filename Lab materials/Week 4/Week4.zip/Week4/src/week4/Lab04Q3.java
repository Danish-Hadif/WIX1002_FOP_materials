/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Scanner;

/**
 *
 * @author Fadzli Sham Hussin
 */
public class Lab04Q3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double sum1 = 0;
        double sumOfSquares = 0;
        int count = 0;
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int score;
        do{
            System.out.print("Enter score (negative score to quit): ");
            score = input.nextInt();
            if (score >= 0) {
                sum1 += score;
                sumOfSquares += (score * score);
                count++;
                
                if (score < min) {
                    min = score;
                }
                if (score > max) {
                    max = score;
                }
            }
                    
        }
        while(score >= 0);
        // Check if at least one valid score was entered
        if (count > 0) {
            double average = sum1 / count;
            double variance = 0;
            double standardDeviation = 0;
            if (count > 1) {
                variance = (sumOfSquares - (sum1 * sum1) / count) / (count - 1);
                standardDeviation = Math.sqrt(variance);
            }
            System.out.printf("%.1f\n",variance);
            System.out.println("Minimum Score: " + min);
            System.out.println("Maximum Score: " + max);
            System.out.printf("Average Score: %.2f\n", average);
            System.out.printf("Standard Deviation: %.2f\n", standardDeviation);
        
        }
        else{
            System.out.println("No valid scores entered ");
        }
    }
    
    
}
