/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Scanner;

/**
 *
 * @author 
 */
public class Lab04Q2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in)
;        System.out.print("Enter a positive integer: ");
        int num1 = input.nextInt();
        int sum = 0;
        for(int i = 1; i<=num1; i++){
            int currentsum = 0;
            for(int j = 1; j<=i;j++){
                currentsum += j;
            }
            sum += currentsum;
        }
        System.out.println(sum);
    }
    
}
