/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package week4;

/**
 *
 * @author Danish hadif
 */
import java.util.Scanner;
import java.util.Random;
public class Tutorial4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int n = 0;
        while(Math.pow(n+1,3)<2000){
            n++;
        }
        System.out.println(n);
        
        //Q1 B
        for(int i = 1; i<=12; i++){
            System.out.println(i*i);
        }
        //C
        Random rand = new Random();
        int[][] arr = new int[4][5];
        for(int i = 0; i<4;i++){
            for(int j = 0; j<5; j++){
                arr[i][j]=rand.nextInt(101);
                System.out.print(arr[i][j]+ "\t");
            }
        }
        System.out.println();
        
        //D
        int givenNumber = 10; // Replace with your given number
        int sum = 0;

        for (int i = 1; i <= givenNumber; i++) {
            sum += i;
        }
        System.out.println("Sum: " + sum);
        //E
        double sum1 = 0.0;

        for (int i = 1; i <= 25; i++) {
             sum1 += (double) i / (26 - i);
        }

        System.out.printf("Sum: %.2f\n", sum1);
        
        //Q2
        /*
        for (int x = 10; x > 0; x--) {
              sum += x;
           }
        */
        /*
        do {
              x += 2;
              y += x;
              System.out.println(x + " and " + y);
            } while (x < 100);
        */
        /*
        for (int x = 1, y = 20; x < y; x++, y -= 2) {
            System.out.println(x + " " + y);
        }
        */
        /*
        int i = 1;
        while (i <= 10) {
           if (i == 10) {
            System.out.println("Program End");
          }
         i++;
        }
        */
        
        //Q3
        int n1 = 1, n2 = 1;
        System.out.print(n1 + " " + n2 + " ");

        for (int i = 3; i <= 10; i++) {
          int next = n1 + n2;
          System.out.print(next + " ");
          n1 = n2;
          n2 = next;
        }
        System.out.println();
        //Q4
        System.out.print("Enter a string: ");
        Scanner input = new Scanner(System.in);
        String word = input.nextLine();
        for(int i = word.length()-1; i>=0;i--){
            System.out.print(word.charAt(i));
        }
        
    }
    
}
