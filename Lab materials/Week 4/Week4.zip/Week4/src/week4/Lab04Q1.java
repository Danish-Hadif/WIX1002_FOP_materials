/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;

import java.util.Scanner;

/**
 *
 * @author Fadzli Sham Hussin
 */
public class Lab04Q1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter an integer; ");
        int num = input.nextInt();
        if(num<0){
            System.out.println("Enter only positive number ");
        }
        else{
            System.out.print("Factors of "+num+" in increasing order is: ");
        }
        for(int i = 1; i<=num; i++){
            if(num % i ==0){
                System.out.print(i+ " ");
            }
        }
        System.out.println();
    }
    
}
