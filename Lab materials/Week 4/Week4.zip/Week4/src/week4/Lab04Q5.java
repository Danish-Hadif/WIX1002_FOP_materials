/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author Fadzli Sham Hussin
 */
public class Lab04Q5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Random rand = new Random();
        int score1 =0;
        int score2 =0;
        System.out.println("=== Welcome to the Two-Player Dice Game! ===");
        System.out.println("Rule: First player to reach MORE than 100 points wins.");
        System.out.println("Special: If you roll a 6, you get another turn!\n");
        while (score1 <= 100 && score2 <= 100) {
            System.out.println("\n----------------------------------------");
            System.out.println("Player 1's turn. Current Score: " + score1);
            boolean player1Again = true;
            while (player1Again && score1 <= 100) {
                System.out.print("Player 1, press Enter to roll the dice...");
                input.nextLine();
                
                int roll = rand.nextInt(6) + 1; // Generates a random number from 1 to 6
                System.out.println("-> You rolled a: " + roll);
                
                score1 += roll;
                System.out.println("-> Player 1 total score: " + score1);
                
                // Special condition: if roll is 6, roll again. Otherwise, end turn.
                if (roll == 6) {
                    System.out.println("✨ You rolled a 6! You get another turn!");
                }
                else{
                    player1Again = false;
                }
                
            }
            if (score1 > 100) {
                System.out.println("\n🎉 Player 1 wins the game with " + score1 + " points!");
                break;
            }
            System.out.println("\n----------------------------------------");
            System.out.println("Player 2's turn. Current Score: " + score2);
            boolean player2Again = true;
            while (player2Again && score2 <= 100) {
                System.out.print("Player 2, press Enter to roll the dice...");
                input.nextLine();
                
                int roll = rand.nextInt(6) + 1;
                System.out.println("-> You rolled a: " + roll);
                
                score2 += roll;
                System.out.println("-> Player 2 total score: " + score2);
                
                // Special condition: if roll is 6, roll again. Otherwise, end turn.
                if (roll == 6) {
                    System.out.println("✨ You rolled a 6! You get another turn!");
                }
                else{
                    player2Again = false;
                }
            }
            if(score2>100){
                System.out.println("\n🎉 Player 2 wins the game with " + score2 + " points!");
                break;
            }
        }
    }
    
}

