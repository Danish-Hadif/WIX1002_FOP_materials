/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Random;

/**
 *
 * @author 
 */
public class Lab04Q8 {
    public static void main(String[] args) {
        Random rand = new Random();
        int n = rand.nextInt(101);
        
        System.out.println("Generated n: " + n);
        
        if (n <= 0) {
            System.out.println("n is 0. No prime numbers to display.");
        }
        else{
            System.out.println("The first " + n + " prime numbers are:");
            int count1 = 0;
            int candidate = 2;
            while (count1 < n) {
                boolean isPrime = true;
                for(int i = 2; i*i<=candidate;i++){
                    if(candidate%i == 0){
                        isPrime = false;
                        break;
                    }
                }
                if (isPrime) {
                    System.out.print(candidate + " ");
                    count1++;
                }
                candidate++;
            }
        }
        
    }
    
}
