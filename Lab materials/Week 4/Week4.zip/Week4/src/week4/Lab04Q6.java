/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package week4;
import java.util.Random;

/**
 *
 * @author Fadzli Sham Hussin
 */
public class Lab04Q6 {
    public static void main(String[] args) {
        int count = 0;
        Random rand = new Random();
        int number = rand.nextInt(100001);
        System.out.println("Random integer is: " + number);
        String numtr = Integer.toString(number);
        for(int i = 0; i<numtr.length();i++ ){
            System.out.println(numtr.charAt(i));
        }
        for(int i = 0; i<numtr.length(); i++){
            int num1 = number;
            num1 = num1/10;
            if(num1<=0){
                break;
            }
            count++; 
            
        }
        System.out.println("The amount of digit in the numbers is: "+count);
    }
    
}
